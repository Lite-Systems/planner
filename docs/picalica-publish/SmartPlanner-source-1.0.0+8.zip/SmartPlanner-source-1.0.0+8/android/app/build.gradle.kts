plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}


android {
    namespace = "com.lite.smartplanner"
    compileSdk = 36 
    buildToolsVersion= "35.0.0"
    ndkVersion = "28.2.13676358"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        applicationId = "com.lite.smartplanner"
        minSdk = 24
        targetSdk = 36
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }
    buildTypes {
        release {
            // TODO: أنشئ مفتاح إصدارك الخاص وفعّل التوقيع به قبل النشر على المتاجر.
            // مثال:
            // signingConfigs {
            //     create("release") {
            //         storeFile = file("your-release-key-file")
            //         storePassword = "store-password"
            //         keyPassword = "key-password"
            //         keyAlias = "upload"
            //     }
            // }
            // signingConfig = signingConfigs.getByName("release")
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
